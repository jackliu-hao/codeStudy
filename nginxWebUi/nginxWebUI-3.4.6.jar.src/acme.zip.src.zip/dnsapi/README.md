# How to use DNS API
DNS api usage:


https://github.com/acmesh-official/acme.sh/wiki/dnsapi

