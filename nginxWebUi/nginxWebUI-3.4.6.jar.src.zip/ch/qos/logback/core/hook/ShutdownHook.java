package ch.qos.logback.core.hook;

import ch.qos.logback.core.spi.ContextAware;

public interface ShutdownHook extends Runnable, ContextAware {}


/* Location:              G:\git\codeReviewLog\nginxWebUi\nginxWebUI-3.4.6.jar!\ch\qos\logback\core\hook\ShutdownHook.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */