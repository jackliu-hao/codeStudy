package ch.qos.logback.core.net.ssl;

public interface SSLComponent {
  SSLConfiguration getSsl();
  
  void setSsl(SSLConfiguration paramSSLConfiguration);
}


/* Location:              G:\git\codeReviewLog\nginxWebUi\nginxWebUI-3.4.6.jar!\ch\qos\logback\core\net\ssl\SSLComponent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */