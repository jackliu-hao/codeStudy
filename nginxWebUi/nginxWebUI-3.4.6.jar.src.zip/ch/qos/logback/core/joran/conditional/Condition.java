package ch.qos.logback.core.joran.conditional;

public interface Condition {
  boolean evaluate();
}


/* Location:              G:\git\codeReviewLog\nginxWebUi\nginxWebUI-3.4.6.jar!\ch\qos\logback\core\joran\conditional\Condition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */