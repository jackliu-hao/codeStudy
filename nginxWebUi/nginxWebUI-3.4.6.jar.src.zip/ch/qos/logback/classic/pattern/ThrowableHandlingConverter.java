/*    */ package ch.qos.logback.classic.pattern;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ThrowableHandlingConverter
/*    */   extends ClassicConverter
/*    */ {
/*    */   boolean handlesThrowable() {
/* 23 */     return true;
/*    */   }
/*    */ }


/* Location:              G:\git\codeReviewLog\nginxWebUi\nginxWebUI-3.4.6.jar!\ch\qos\logback\classic\pattern\ThrowableHandlingConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */