package ch.qos.logback.classic.net;

class SocketAcceptor extends Thread {
  public void run() {}
}


/* Location:              G:\git\codeReviewLog\nginxWebUi\nginxWebUI-3.4.6.jar!\ch\qos\logback\classic\net\SocketAcceptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */