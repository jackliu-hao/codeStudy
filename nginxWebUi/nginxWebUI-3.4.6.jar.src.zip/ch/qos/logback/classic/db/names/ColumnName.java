/*    */ package ch.qos.logback.classic.db.names;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ColumnName
/*    */ {
/* 18 */   EVENT_ID,
/*    */   
/* 20 */   TIMESTMP, FORMATTED_MESSAGE, LOGGER_NAME, LEVEL_STRING, THREAD_NAME, REFERENCE_FLAG, ARG0, ARG1, ARG2, ARG3, CALLER_FILENAME, CALLER_CLASS, CALLER_METHOD, CALLER_LINE,
/*    */ 
/*    */   
/* 23 */   MAPPED_KEY, MAPPED_VALUE,
/*    */   
/* 25 */   I, TRACE_LINE;
/*    */ }


/* Location:              G:\git\codeReviewLog\nginxWebUi\nginxWebUI-3.4.6.jar!\ch\qos\logback\classic\db\names\ColumnName.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */