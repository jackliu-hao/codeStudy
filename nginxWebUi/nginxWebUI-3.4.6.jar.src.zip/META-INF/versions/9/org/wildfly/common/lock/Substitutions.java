package META-INF.versions.9.org.wildfly.common.lock;

final class Substitutions {}


/* Location:              G:\git\codeReviewLog\nginxWebUi\nginxWebUI-3.4.6.jar!\META-INF\versions\9\org\wildfly\common\lock\Substitutions.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       1.1.3
 */