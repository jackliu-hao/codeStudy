/*    */ package META-INF.versions.9.org.wildfly.common.cpu;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProcessorInfo
/*    */ {
/*    */   public static int availableProcessors() {
/* 29 */     return Runtime.getRuntime().availableProcessors();
/*    */   }
/*    */ }


/* Location:              G:\git\codeReviewLog\nginxWebUi\nginxWebUI-3.4.6.jar!\META-INF\versions\9\org\wildfly\common\cpu\ProcessorInfo.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       1.1.3
 */