/*    */ package META-INF.versions.9.org.wildfly.common.os;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ProcessRedirect
/*    */ {
/*    */   public static ProcessBuilder.Redirect discard() {
/* 25 */     return ProcessBuilder.Redirect.DISCARD;
/*    */   }
/*    */ }


/* Location:              G:\git\codeReviewLog\nginxWebUi\nginxWebUI-3.4.6.jar!\META-INF\versions\9\org\wildfly\common\os\ProcessRedirect.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       1.1.3
 */